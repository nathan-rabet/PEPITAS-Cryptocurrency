var annotated_dup =
[
    [ "Block", "struct_block.html", "struct_block" ],
    [ "BlockData", "struct_block_data.html", "struct_block_data" ],
    [ "blockinfo", "structblockinfo.html", "structblockinfo" ],
    [ "ChunkBlockchain", "struct_chunk_blockchain.html", "struct_chunk_blockchain" ],
    [ "connection", "structconnection.html", "structconnection" ],
    [ "infos_st", "structinfos__st.html", "structinfos__st" ],
    [ "Neighbour", "struct_neighbour.html", "struct_neighbour" ],
    [ "Node", "struct_node.html", "struct_node" ],
    [ "th_arg", "structth__arg.html", "structth__arg" ],
    [ "Transaction", "struct_transaction.html", "struct_transaction" ],
    [ "TransactionData", "struct_transaction_data.html", "struct_transaction_data" ],
    [ "validators_state_header", "structvalidators__state__header.html", "structvalidators__state__header" ],
    [ "validators_state_item", "structvalidators__state__item.html", "structvalidators__state__item" ],
    [ "Wallet", "struct_wallet.html", "struct_wallet" ]
];