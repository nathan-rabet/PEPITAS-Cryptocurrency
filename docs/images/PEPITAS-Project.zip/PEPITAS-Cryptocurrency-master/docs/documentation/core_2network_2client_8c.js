var core_2network_2client_8c =
[
    [ "client_thread", "core_2network_2client_8c.html#a351b786eb662460f254da2ff204fcfcc", null ],
    [ "find_empty_connection", "core_2network_2client_8c.html#ac6f2cb10ccd85dd8e65b4523d734bcfe", null ],
    [ "get_my_node", "core_2network_2client_8c.html#a745cc052bf8990bd3189b857a1d29f40", null ],
    [ "is_in_neighbours", "core_2network_2client_8c.html#a0dc5c7ebcc87bb9c0fc1b2dcb69596c7", null ],
    [ "listen_to", "core_2network_2client_8c.html#a7be5d0a5ee88cfd1a654fc4813273708", null ],
    [ "load_neighbours", "core_2network_2client_8c.html#a641a9d3cb0669b127493779eefc8b56c", null ],
    [ "number_neighbours", "core_2network_2client_8c.html#acec8d99c29599378ad06a91d4911587f", null ],
    [ "print_neighbours", "core_2network_2client_8c.html#ae814feddaa9902371625b42131b1a7f4", null ],
    [ "remove_neighbour", "core_2network_2client_8c.html#ac8ccea3b50ff7a7e599cfa8fa774af8e", null ],
    [ "save_neighbours", "core_2network_2client_8c.html#aab146f25715d4241dd2cfc64750cdd0d", null ],
    [ "set_neighbour", "core_2network_2client_8c.html#a65f3df28a906d619b5f408a26aec7649", null ],
    [ "client_connections", "core_2network_2client_8c.html#a0ba5d3a056115234ab9ed718797c2953", null ]
];