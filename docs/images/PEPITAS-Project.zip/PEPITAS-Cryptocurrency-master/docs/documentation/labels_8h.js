var labels_8h =
[
    [ "add_new_blockinfo", "labels_8h.html#a2abce63b237dd17f1a7994eef33c13f2", null ],
    [ "change_label_text", "labels_8h.html#ae4c608b5626430bac55322e32309bf8f", null ],
    [ "balance_1", "labels_8h.html#ab43804688ba42c6200ce731eb35c5dc8", null ],
    [ "balance_2", "labels_8h.html#a868e43b57c30e358fe58e0deb101f42a", null ],
    [ "block_amount_label", "labels_8h.html#aef72f064f1fc788edba39ced4f4735d5", null ],
    [ "connections_label", "labels_8h.html#ae197a17a69bd4320a69c3945369d802e", null ],
    [ "mempool_label", "labels_8h.html#a48095bf105fef9a39a872144a56e23ab", null ],
    [ "stake_label1", "labels_8h.html#a4722da076b88ed9d7695ae3d38945692", null ],
    [ "stake_label2", "labels_8h.html#a16f98e00efbcc9f5356cd26ddde7cc53", null ],
    [ "stake_label3", "labels_8h.html#ac7f6d61c5f9e17e359513909d01dbbd0", null ],
    [ "synchro_label", "labels_8h.html#af7ca2b7a2cb2c8e008ef7c338eb725cc", null ]
];