var dir_68267d1309a1af8e8297ef4c3efbcdba =
[
    [ "core", "dir_aebb8dcc11953d78e620bbef0b9e2183.html", "dir_aebb8dcc11953d78e620bbef0b9e2183" ],
    [ "client.c", "client_8c.html", "client_8c" ],
    [ "genesis.c", "genesis_8c.html", "genesis_8c" ],
    [ "serverdoor.c", "serverdoor_8c.html", "serverdoor_8c" ]
];