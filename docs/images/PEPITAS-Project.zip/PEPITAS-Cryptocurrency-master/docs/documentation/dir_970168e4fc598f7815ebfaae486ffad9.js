var dir_970168e4fc598f7815ebfaae486ffad9 =
[
    [ "block.h", "block_8h.html", "block_8h" ],
    [ "blockchain_header.h", "blockchain__header_8h.html", "blockchain__header_8h" ],
    [ "transaction.h", "transaction_8h.html", "transaction_8h" ],
    [ "wallet.h", "wallet_8h.html", "wallet_8h" ]
];