var dir_83fbd955906e9032510966d415c56495 =
[
    [ "client.h", "network_2client_8h.html", "network_2client_8h" ],
    [ "get_data.h", "get__data_8h.html", "get__data_8h" ],
    [ "network.h", "network_8h.html", "network_8h" ],
    [ "send_data.h", "send__data_8h.html", "send__data_8h" ],
    [ "server.h", "server_8h.html", "server_8h" ]
];