var blockchain__header_8c =
[
    [ "gen_blockchain_header", "blockchain__header_8c.html#a1011109fa5281e4b6406c390393cd051", null ],
    [ "get_receiver_remaining_money", "blockchain__header_8c.html#a535ef7a9f8d2749d92cf31c98c6ac293", null ],
    [ "write_block_header", "blockchain__header_8c.html#a0096ca7d050954ee9a259ebdcd787519", null ]
];