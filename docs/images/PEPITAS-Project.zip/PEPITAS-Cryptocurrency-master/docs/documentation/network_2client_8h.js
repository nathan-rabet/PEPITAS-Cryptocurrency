var network_2client_8h =
[
    [ "client_thread", "network_2client_8h.html#a351b786eb662460f254da2ff204fcfcc", null ],
    [ "find_empty_connection", "network_2client_8h.html#a2ea79fcac5d457bfb388c14ed6ae7d41", null ],
    [ "get_my_node", "network_2client_8h.html#a745cc052bf8990bd3189b857a1d29f40", null ],
    [ "is_in_neighbours", "network_2client_8h.html#a0dc5c7ebcc87bb9c0fc1b2dcb69596c7", null ],
    [ "listen_to", "network_2client_8h.html#a7be5d0a5ee88cfd1a654fc4813273708", null ],
    [ "load_neighbours", "network_2client_8h.html#a641a9d3cb0669b127493779eefc8b56c", null ],
    [ "number_neighbours", "network_2client_8h.html#acec8d99c29599378ad06a91d4911587f", null ],
    [ "print_neighbours", "network_2client_8h.html#ae814feddaa9902371625b42131b1a7f4", null ],
    [ "remove_neighbour", "network_2client_8h.html#ac8ccea3b50ff7a7e599cfa8fa774af8e", null ],
    [ "save_neighbours", "network_2client_8h.html#aab146f25715d4241dd2cfc64750cdd0d", null ],
    [ "set_neighbour", "network_2client_8h.html#a65f3df28a906d619b5f408a26aec7649", null ]
];