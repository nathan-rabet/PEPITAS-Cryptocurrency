var genesis_8c =
[
    [ "get_infos", "genesis_8c.html#a480459f3451fa57a66df548ca0b408e3", null ],
    [ "main", "genesis_8c.html#ae66f6b31b5ad750f1fe042a706a4e3d4", null ],
    [ "new_transaction", "genesis_8c.html#a597346567fc95cf305a94063df3e86c3", null ],
    [ "ac_infos", "genesis_8c.html#a2f0f3a6761406ed81c1bce008b2b20f8", null ],
    [ "client_connections", "genesis_8c.html#a0ba5d3a056115234ab9ed718797c2953", null ]
];