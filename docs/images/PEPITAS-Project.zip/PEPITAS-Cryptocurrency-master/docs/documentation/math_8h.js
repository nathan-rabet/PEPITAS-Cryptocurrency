var math_8h =
[
    [ "MAX", "math_8h.html#afa99ec4acc4ecb2dc3c2d05da15d0e3f", null ],
    [ "MIN", "math_8h.html#a3acffbd305ee72dcd4593c0d8af64a4f", null ]
];