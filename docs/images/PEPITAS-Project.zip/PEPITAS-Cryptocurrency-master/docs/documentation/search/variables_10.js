var searchData=
[
  ['thread_776',['thread',['../structconnection.html#a01f75a9ad916f63a94e06a27635ba278',1,'connection']]],
  ['total_5fstake_777',['total_stake',['../structvalidators__state__header.html#a7afc99e4040999c8b7887162be158437',1,'validators_state_header']]],
  ['total_5ftransa_5flabel_778',['total_transa_label',['../ui_8c.html#acc866aa77170d1eaec44d9085748d6d5',1,'ui.c']]],
  ['transa_5famount_779',['transa_amount',['../ui_8c.html#a5a64b67ddec08a9b9d81b4facd94047a',1,'ui.c']]],
  ['transa_5fnumber_5flabel_780',['transa_number_label',['../ui_8c.html#a92ee61739bde1f3a7d4eaf16edc12f92',1,'ui.c']]],
  ['transaction_5fdata_781',['transaction_data',['../struct_transaction.html#a9146d56260acb20560c4f8d46c429e55',1,'Transaction']]],
  ['transaction_5fsignature_782',['transaction_signature',['../struct_transaction.html#a86020827f2942b4ee3e7dd12f8e08fb5',1,'Transaction']]],
  ['transaction_5ftimestamp_783',['transaction_timestamp',['../struct_transaction_data.html#a08f7318370233b1a2f1b7d6b5737abf6',1,'TransactionData']]],
  ['transactions_784',['transactions',['../struct_block_data.html#acf585c1809511c4f5b5366bb2bc2e855',1,'BlockData::transactions()'],['../structblockinfo.html#a78b17b7349d95f6beca80174eec931ea',1,'blockinfo::transactions()']]],
  ['ts_5fcon_785',['ts_con',['../ui_8c.html#a3d023a78babb0df3470dc81314feadd5',1,'ui.c']]],
  ['ts_5fth_786',['ts_th',['../ui_8c.html#a25a91552d8574c51a2b6e9a15663eeee',1,'ui.c']]],
  ['tv_5fcon_787',['tv_con',['../ui_8c.html#a7d4f1acd200f42ce8a25b24bdcd11f6e',1,'ui.c']]],
  ['tv_5fth_788',['tv_th',['../ui_8c.html#a61df27324bc5fa1509abd1ef234f0368',1,'ui.c']]],
  ['type_789',['type',['../struct_transaction_data.html#aff17911edc8208aa8ddb1c7c52c78389',1,'TransactionData']]]
];
