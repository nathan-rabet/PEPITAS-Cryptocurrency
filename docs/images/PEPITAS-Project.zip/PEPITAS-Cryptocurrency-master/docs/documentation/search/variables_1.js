var searchData=
[
  ['balance_5f1_689',['balance_1',['../labels_8h.html#ab43804688ba42c6200ce731eb35c5dc8',1,'balance_1():&#160;ui.c'],['../ui_8h.html#ab43804688ba42c6200ce731eb35c5dc8',1,'balance_1():&#160;ui.c'],['../ui_8c.html#ab43804688ba42c6200ce731eb35c5dc8',1,'balance_1():&#160;ui.c']]],
  ['balance_5f2_690',['balance_2',['../labels_8h.html#a868e43b57c30e358fe58e0deb101f42a',1,'balance_2():&#160;ui.c'],['../ui_8h.html#a868e43b57c30e358fe58e0deb101f42a',1,'balance_2():&#160;ui.c'],['../ui_8c.html#a868e43b57c30e358fe58e0deb101f42a',1,'balance_2():&#160;ui.c']]],
  ['block_5famount_5flabel_691',['block_amount_label',['../labels_8h.html#aef72f064f1fc788edba39ced4f4735d5',1,'block_amount_label():&#160;ui.c'],['../ui_8h.html#aef72f064f1fc788edba39ced4f4735d5',1,'block_amount_label():&#160;ui.c'],['../ui_8c.html#aef72f064f1fc788edba39ced4f4735d5',1,'block_amount_label():&#160;ui.c']]],
  ['block_5fdata_692',['block_data',['../struct_block.html#aa4ad7aceb75575844e2db05c93709bba',1,'Block']]],
  ['block_5ferror_5flabel_693',['block_error_label',['../ui_8c.html#a23771b2624008125017ad71bbec0924b',1,'ui.c']]],
  ['block_5fheight_694',['block_height',['../ui_8c.html#ac58136f7a44535d618d5cc333265f7c5',1,'ui.c']]],
  ['block_5fheight_5flabel_695',['block_height_label',['../ui_8c.html#a9a98b342050f650b678b3f482e70923d',1,'ui.c']]],
  ['block_5fheight_5fvalidity_696',['block_height_validity',['../structvalidators__state__header.html#ae7febe2cb0f1630846d41a8547feebf5',1,'validators_state_header']]],
  ['block_5fsignature_697',['block_signature',['../struct_block.html#af74f4943494e179408bedd4841fadc1b',1,'Block']]],
  ['block_5ftime_5flabel_698',['block_time_label',['../ui_8c.html#a5ab062c2a9ac5540ab89253fdacfedd6',1,'ui.c']]],
  ['block_5ftimestamp_699',['block_timestamp',['../struct_block_data.html#a35920c7529ccc1863e3fd10f39bb1015',1,'BlockData']]],
  ['blocksinfo_700',['blocksinfo',['../ui_8h.html#a46ad7408bf2f0e142f3c124e26bd4b19',1,'ui.h']]]
];
