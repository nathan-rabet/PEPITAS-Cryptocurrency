var searchData=
[
  ['t_5ftype_5fadd_5fstake_873',['T_TYPE_ADD_STAKE',['../transaction_8h.html#ab89b46767fb01957106298a1e1b71cc4',1,'transaction.h']]],
  ['t_5ftype_5fdefault_874',['T_TYPE_DEFAULT',['../transaction_8h.html#a844858e98ed01783bad48db7e850ea00',1,'transaction.h']]],
  ['t_5ftype_5fpunish_5fstake_875',['T_TYPE_PUNISH_STAKE',['../transaction_8h.html#aff047683b311c8ec9db70bb42b235691',1,'transaction.h']]],
  ['t_5ftype_5freward_5fstake_876',['T_TYPE_REWARD_STAKE',['../transaction_8h.html#a25db318d424517866d13068be4889cc1',1,'transaction.h']]],
  ['t_5ftype_5fwithdraw_5fstake_877',['T_TYPE_WITHDRAW_STAKE',['../transaction_8h.html#a96043a50e70275b11a4adb73a30e71ec',1,'transaction.h']]],
  ['tcp_5fuser_5ftimeout_878',['TCP_USER_TIMEOUT',['../network_8h.html#a2279fe1842cc4dd92e743a1b3e4c6e0e',1,'network.h']]],
  ['test_5ffailed_879',['TEST_FAILED',['../tests__macros_8h.html#ab5bcf634df6bc2cce66f6522b3ac9aa0',1,'tests_macros.h']]],
  ['test_5fpassed_880',['TEST_PASSED',['../tests__macros_8h.html#a55845f330076437281d5530a2d5d81bc',1,'tests_macros.h']]],
  ['test_5fwarning_881',['TEST_WARNING',['../tests__macros_8h.html#abac1e138222ec3fa205e0ed0713cd725',1,'tests_macros.h']]],
  ['trans_5ft_882',['TRANS_T',['../block_8h.html#adf3c5835f38adeb199ba300dbdf200f4',1,'TRANS_T():&#160;block.h'],['../transaction_8h.html#adf3c5835f38adeb199ba300dbdf200f4',1,'TRANS_T():&#160;transaction.h']]],
  ['transaction_5fdata_5fsize_883',['TRANSACTION_DATA_SIZE',['../transaction_8h.html#a23a3fd6c444964ae25e3046fbd29bd86',1,'transaction.h']]],
  ['transaction_5fsize_884',['TRANSACTION_SIZE',['../transaction_8h.html#a2feb985dba127602ea5a6c5b6822c969',1,'transaction.h']]]
];
