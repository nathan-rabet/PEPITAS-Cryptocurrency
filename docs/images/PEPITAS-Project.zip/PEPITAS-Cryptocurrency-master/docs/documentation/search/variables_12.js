var searchData=
[
  ['validator_5fid_791',['validator_id',['../structinfos__st.html#a18bdac62518b6603f5d6653624ce7d2d',1,'infos_st']]],
  ['validator_5fpkey_792',['validator_pkey',['../structvalidators__state__item.html#ae734d826e591d1aaff041b03a9718f24',1,'validators_state_item']]],
  ['validator_5fpower_793',['validator_power',['../structvalidators__state__item.html#a759aed033e26f4349569f0d3f16c9026',1,'validators_state_item']]],
  ['validators_5fpublic_5fkeys_794',['validators_public_keys',['../struct_block_data.html#ae6f252ad04c4e1be04547b6591bc290a',1,'BlockData']]],
  ['validators_5fvotes_795',['validators_votes',['../struct_block.html#a844db3988bb76609b2ca47e6c19c98eb',1,'Block']]],
  ['validators_5fvotes_5flabel_796',['validators_votes_label',['../ui_8c.html#a1b51e8f243dd78092b7aff4604d453f8',1,'ui.c']]],
  ['vote_5fsignature_797',['vote_signature',['../struct_block.html#a583563e61e9fe701bf4edb94596c20e4',1,'Block']]]
];
