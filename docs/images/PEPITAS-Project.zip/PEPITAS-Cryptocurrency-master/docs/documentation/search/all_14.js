var searchData=
[
  ['ui_2ec_393',['ui.c',['../ui_8c.html',1,'']]],
  ['ui_2eh_394',['ui.h',['../ui_8h.html',1,'']]],
  ['unit_5ftesting_2ec_395',['unit_testing.c',['../unit__testing_8c.html',1,'']]],
  ['update_5fblockchain_396',['update_blockchain',['../client_8h.html#a2aa6779c93462c07f8a674546b72bd8b',1,'update_blockchain(infos_st *infos, size_t index_client):&#160;atrier.c'],['../atrier_8c.html#a2aa6779c93462c07f8a674546b72bd8b',1,'update_blockchain(infos_st *infos, size_t index_client):&#160;atrier.c']]],
  ['update_5fblockchain_5fheight_397',['update_blockchain_height',['../client_8h.html#a6a6632fc31369b450613587243a58807',1,'update_blockchain_height(infos_st *infos):&#160;atrier.c'],['../atrier_8c.html#a6a6632fc31369b450613587243a58807',1,'update_blockchain_height(infos_st *infos):&#160;atrier.c']]],
  ['update_5flabels_398',['update_labels',['../ui_8h.html#af1854ec5ff4099ed69a1b51a3fd3b3df',1,'update_labels():&#160;ui.c'],['../ui_8c.html#af1854ec5ff4099ed69a1b51a3fd3b3df',1,'update_labels():&#160;ui.c']]],
  ['update_5fpdt_399',['update_pdt',['../client_8h.html#a35c808540bae041c9d4f83012c639426',1,'update_pdt(int number):&#160;atrier.c'],['../atrier_8c.html#a35c808540bae041c9d4f83012c639426',1,'update_pdt(int number):&#160;atrier.c']]],
  ['update_5fpending_5ftransactions_5flist_400',['update_pending_transactions_list',['../client_8h.html#a22202ffd77ff472dddbec2ac501025f4',1,'update_pending_transactions_list():&#160;atrier.c'],['../atrier_8c.html#a22202ffd77ff472dddbec2ac501025f4',1,'update_pending_transactions_list():&#160;atrier.c']]],
  ['update_5fsync_401',['update_sync',['../ui_8h.html#aa390af6abf83347d6b141cee7b7dde29',1,'update_sync(size_t actual, size_t final):&#160;ui.c'],['../ui_8c.html#aa390af6abf83347d6b141cee7b7dde29',1,'update_sync(size_t actual, size_t final):&#160;ui.c']]],
  ['update_5fvalidators_5fstate_402',['update_validators_state',['../validators_8h.html#acb995f2242245cf16710ddba0a0724bb',1,'update_validators_state(Block *block):&#160;validators.c'],['../validators_8c.html#acb995f2242245cf16710ddba0a0724bb',1,'update_validators_state(Block *block):&#160;validators.c']]],
  ['update_5fwallet_5fwith_5fblock_403',['update_wallet_with_block',['../block_8h.html#aa460be06109601a5626d1acb251e1602',1,'update_wallet_with_block(Block block):&#160;block.c'],['../block_8c.html#aa460be06109601a5626d1acb251e1602',1,'update_wallet_with_block(Block block):&#160;block.c']]],
  ['user_5fstake_404',['user_stake',['../structvalidators__state__item.html#a27cda28eb765a83f8b4dc136253aadbe',1,'validators_state_item']]]
];
