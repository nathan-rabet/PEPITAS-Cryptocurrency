var searchData=
[
  ['client_2ec_462',['client.c',['../client_8c.html',1,'(Global Namespace)'],['../core_2network_2client_8c.html',1,'(Global Namespace)']]],
  ['client_2eh_463',['client.h',['../client_8h.html',1,'(Global Namespace)'],['../network_2client_8h.html',1,'(Global Namespace)']]],
  ['client_5ftest_2ec_464',['client_test.c',['../client__test_8c.html',1,'']]],
  ['client_5ftest_2eh_465',['client_test.h',['../client__test_8h.html',1,'']]]
];
