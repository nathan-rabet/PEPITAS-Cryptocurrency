var searchData=
[
  ['name_5fentry_5fcon_221',['name_entry_con',['../ui_8c.html#af7c418915599a0feee638b616aca25ec',1,'ui.c']]],
  ['nb_5fblock_5fper_5fchunk_222',['NB_BLOCK_PER_CHUNK',['../block_8h.html#aa4fef9ef09e17d20a5a4c29685486104',1,'NB_BLOCK_PER_CHUNK():&#160;block.h'],['../block__test_8c.html#aa4fef9ef09e17d20a5a4c29685486104',1,'NB_BLOCK_PER_CHUNK():&#160;block_test.c']]],
  ['nb_5fblocks_223',['nb_blocks',['../struct_chunk_blockchain.html#aec59611acf2a3f1faedbfbec127e1c83',1,'ChunkBlockchain']]],
  ['nb_5ffake_5fvalidators_224',['NB_FAKE_VALIDATORS',['../_g_e_n__validators__file_8c.html#a76f81d5b5681759e4541e5189cc0ccdb',1,'GEN_validators_file.c']]],
  ['nb_5fhard_5fcoded_5faddr_225',['NB_HARD_CODED_ADDR',['../network_8h.html#add095a1aa250a89d084747a7a9bc9397',1,'network.h']]],
  ['nb_5fmock_5fblocks_226',['NB_MOCK_BLOCKS',['../block__test_8c.html#a007cd260649f20ea0facfccd8abe509a',1,'block_test.c']]],
  ['nb_5frsa_5fchunk_227',['NB_RSA_CHUNK',['../validators_8c.html#a63ae7a32d04d17e1ac38f0d19197e109',1,'validators.c']]],
  ['nb_5ftransactions_228',['nb_transactions',['../struct_block_data.html#a6a025b5ff7c48992e8d360c35f02b7e8',1,'BlockData']]],
  ['nb_5fvalidators_229',['nb_validators',['../struct_block_data.html#a7e3cf87673d9cf2f1b5341ad61427fea',1,'BlockData::nb_validators()'],['../structvalidators__state__header.html#a4cc2cbf07a33d826c574e4cd59ec2cb8',1,'validators_state_header::nb_validators()']]],
  ['nb_5fvalidators_5flabel_230',['nb_validators_label',['../ui_8c.html#a79eea76daf4b03659d5fbeec022d2185',1,'ui.c']]],
  ['nb_5fvotes_5fbitmap_231',['NB_VOTES_BITMAP',['../block_8h.html#a46854d5bd508e517e4ae7902dd8ac231',1,'block.h']]],
  ['neighbour_232',['Neighbour',['../struct_neighbour.html',1,'Neighbour'],['../network_8h.html#af516980a1d1fa7f6e92cafb59e634556',1,'Neighbour():&#160;network.h']]],
  ['neighbours_233',['neighbours',['../struct_node.html#a64982c1c406035f198bfe705faf683b2',1,'Node']]],
  ['network_2ec_234',['network.c',['../network_8c.html',1,'']]],
  ['network_2eh_235',['network.h',['../network_8h.html',1,'']]],
  ['network_5ftest_236',['network_test',['../client__test_8h.html#ade76ed0fdf28b393fbdc89e611688256',1,'network_test():&#160;client_test.c'],['../client__test_8c.html#ade76ed0fdf28b393fbdc89e611688256',1,'network_test():&#160;client_test.c']]],
  ['new_5ftransaction_237',['new_transaction',['../client_8h.html#a597346567fc95cf305a94063df3e86c3',1,'new_transaction(char type, char *rc_pk, size_t amount, char cause[512], char asset[512]):&#160;atrier.c'],['../atrier_8c.html#a597346567fc95cf305a94063df3e86c3',1,'new_transaction(char type, char *rc_pk, size_t amount, char cause[512], char asset[512]):&#160;atrier.c'],['../genesis_8c.html#a597346567fc95cf305a94063df3e86c3',1,'new_transaction(char type, char *rc_pk, size_t amount, char cause[512], char asset[512]):&#160;atrier.c']]],
  ['node_238',['Node',['../struct_node.html',1,'Node'],['../network_8h.html#a3b09f37e675bcd48a01bf22155996872',1,'Node():&#160;network.h']]],
  ['nodeserver_239',['NODESERVER',['../network_8h.html#a990e4ab4f7babf69de0109080b0f7c72',1,'network.h']]],
  ['number_5fneighbours_240',['number_neighbours',['../network_2client_8h.html#acec8d99c29599378ad06a91d4911587f',1,'number_neighbours(char who):&#160;client.c'],['../core_2network_2client_8c.html#acec8d99c29599378ad06a91d4911587f',1,'number_neighbours(char who):&#160;client.c']]]
];
