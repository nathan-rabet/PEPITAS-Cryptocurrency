var searchData=
[
  ['nb_5fblock_5fper_5fchunk_853',['NB_BLOCK_PER_CHUNK',['../block_8h.html#aa4fef9ef09e17d20a5a4c29685486104',1,'NB_BLOCK_PER_CHUNK():&#160;block.h'],['../block__test_8c.html#aa4fef9ef09e17d20a5a4c29685486104',1,'NB_BLOCK_PER_CHUNK():&#160;block_test.c']]],
  ['nb_5ffake_5fvalidators_854',['NB_FAKE_VALIDATORS',['../_g_e_n__validators__file_8c.html#a76f81d5b5681759e4541e5189cc0ccdb',1,'GEN_validators_file.c']]],
  ['nb_5fhard_5fcoded_5faddr_855',['NB_HARD_CODED_ADDR',['../network_8h.html#add095a1aa250a89d084747a7a9bc9397',1,'network.h']]],
  ['nb_5fmock_5fblocks_856',['NB_MOCK_BLOCKS',['../block__test_8c.html#a007cd260649f20ea0facfccd8abe509a',1,'block_test.c']]],
  ['nb_5frsa_5fchunk_857',['NB_RSA_CHUNK',['../validators_8c.html#a63ae7a32d04d17e1ac38f0d19197e109',1,'validators.c']]],
  ['nb_5fvotes_5fbitmap_858',['NB_VOTES_BITMAP',['../block_8h.html#a46854d5bd508e517e4ae7902dd8ac231',1,'block.h']]],
  ['nodeserver_859',['NODESERVER',['../network_8h.html#a990e4ab4f7babf69de0109080b0f7c72',1,'network.h']]]
];
