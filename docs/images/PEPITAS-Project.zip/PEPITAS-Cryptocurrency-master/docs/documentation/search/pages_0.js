var searchData=
[
  ['pepitas_20network_20protocol_888',['PEPITAS NETWORK PROTOCOL',['../md__home_runner_work__p_e_p_i_t_a_s-_cryptocurrency__p_e_p_i_t_a_s-_cryptocurrency__p2_p__protocol.html',1,'']]],
  ['pepitas_889',['PEPITAS',['../md__home_runner_work__p_e_p_i_t_a_s-_cryptocurrency__p_e_p_i_t_a_s-_cryptocurrency__r_e_a_d_m_e.html',1,'']]],
  ['pepitas_20validation_20protocol_890',['PEPITAS VALIDATION PROTOCOL',['../md__home_runner_work__p_e_p_i_t_a_s-_cryptocurrency__p_e_p_i_t_a_s-_cryptocurrency__v_a_l_i_d_a_t_i_o_n__protocol.html',1,'']]]
];
