var searchData=
[
  ['define_5fnb_5fvalidators_545',['define_nb_validators',['../validators_8c.html#a47f27f9d65e1a683a3eb7da762d267b2',1,'validators.c']]],
  ['delete_5fepochs_546',['delete_epochs',['../block_8h.html#a26d68c21f6e7bedeb73586554f4a9526',1,'delete_epochs(size_t height):&#160;block.c'],['../block_8c.html#a26d68c21f6e7bedeb73586554f4a9526',1,'delete_epochs(size_t height):&#160;block.c']]]
];
