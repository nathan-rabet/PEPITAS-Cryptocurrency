var searchData=
[
  ['epoch_5fid_723',['epoch_id',['../struct_block_data.html#a278b59ca8ce2a9b806c99a450d00dfa7',1,'BlockData']]],
  ['error_5flabel_724',['error_label',['../ui_8c.html#a476e49ba86b596073ff2711ff3c0273a',1,'ui.c']]]
];
