var searchData=
[
  ['wallet_453',['Wallet',['../struct_wallet.html',1,'']]]
];
