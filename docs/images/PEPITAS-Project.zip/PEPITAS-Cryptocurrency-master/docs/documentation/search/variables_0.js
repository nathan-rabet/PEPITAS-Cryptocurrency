var searchData=
[
  ['ac_5finfos_682',['ac_infos',['../client_8c.html#a2f0f3a6761406ed81c1bce008b2b20f8',1,'ac_infos():&#160;client.c'],['../atrier_8c.html#a2f0f3a6761406ed81c1bce008b2b20f8',1,'ac_infos():&#160;atrier.c'],['../genesis_8c.html#a2f0f3a6761406ed81c1bce008b2b20f8',1,'ac_infos():&#160;genesis.c'],['../unit__testing_8c.html#a2f0f3a6761406ed81c1bce008b2b20f8',1,'ac_infos():&#160;unit_testing.c']]],
  ['actual_5fclient_5fheight_683',['actual_client_height',['../structconnection.html#a6097580640c5221264615c155707c6bd',1,'connection']]],
  ['actual_5fheight_684',['actual_height',['../structinfos__st.html#abecc2f44ff318c3b1e4fa2c7f3d5cbd8',1,'infos_st']]],
  ['amount_685',['amount',['../struct_transaction_data.html#a09041dfaf996bee7cc220f076325f2ec',1,'TransactionData::amount()'],['../struct_wallet.html#a09041dfaf996bee7cc220f076325f2ec',1,'Wallet::amount()']]],
  ['as_5fepoch_686',['as_epoch',['../structinfos__st.html#a0a02f636548ba9d62ff4f2c748ab72bf',1,'infos_st']]],
  ['asset_687',['asset',['../struct_transaction_data.html#a389eb9159e102222cddc03b515bfc23e',1,'TransactionData']]],
  ['asset_5fentry_688',['asset_entry',['../ui_8c.html#a366bfbc5429306ff4bb09a98310efe16',1,'ui.c']]]
];
