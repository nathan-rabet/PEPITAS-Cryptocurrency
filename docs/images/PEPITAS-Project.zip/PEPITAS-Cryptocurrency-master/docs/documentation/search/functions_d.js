var searchData=
[
  ['network_5ftest_599',['network_test',['../client__test_8h.html#ade76ed0fdf28b393fbdc89e611688256',1,'network_test():&#160;client_test.c'],['../client__test_8c.html#ade76ed0fdf28b393fbdc89e611688256',1,'network_test():&#160;client_test.c']]],
  ['new_5ftransaction_600',['new_transaction',['../client_8h.html#a597346567fc95cf305a94063df3e86c3',1,'new_transaction(char type, char *rc_pk, size_t amount, char cause[512], char asset[512]):&#160;atrier.c'],['../atrier_8c.html#a597346567fc95cf305a94063df3e86c3',1,'new_transaction(char type, char *rc_pk, size_t amount, char cause[512], char asset[512]):&#160;atrier.c'],['../genesis_8c.html#a597346567fc95cf305a94063df3e86c3',1,'new_transaction(char type, char *rc_pk, size_t amount, char cause[512], char asset[512]):&#160;atrier.c']]],
  ['number_5fneighbours_601',['number_neighbours',['../network_2client_8h.html#acec8d99c29599378ad06a91d4911587f',1,'number_neighbours(char who):&#160;client.c'],['../core_2network_2client_8c.html#acec8d99c29599378ad06a91d4911587f',1,'number_neighbours(char who):&#160;client.c']]]
];
