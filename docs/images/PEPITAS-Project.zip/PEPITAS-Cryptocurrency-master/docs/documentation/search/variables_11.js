var searchData=
[
  ['user_5fstake_790',['user_stake',['../structvalidators__state__item.html#a27cda28eb765a83f8b4dc136253aadbe',1,'validators_state_item']]]
];
