var searchData=
[
  ['epoch_5fvalidation_5fprocess_547',['epoch_validation_process',['../get__data_8h.html#aa5eb9e1d62d1366fdebe19a5819d1bde',1,'epoch_validation_process(int blockfile, size_t height, int id):&#160;get_data.c'],['../get__data_8c.html#aa5eb9e1d62d1366fdebe19a5819d1bde',1,'epoch_validation_process(int blockfile, size_t height, int id):&#160;get_data.c']]]
];
