var searchData=
[
  ['epoch_5fman_2ec_466',['epoch_man.c',['../epoch__man_8c.html',1,'']]],
  ['epoch_5fman_2eh_467',['epoch_man.h',['../epoch__man_8h.html',1,'']]]
];
