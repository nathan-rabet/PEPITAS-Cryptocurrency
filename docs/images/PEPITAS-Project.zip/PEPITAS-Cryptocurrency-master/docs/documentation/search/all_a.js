var searchData=
[
  ['join_5fnetwork_5fdoor_186',['join_network_door',['../client_8h.html#a4bc5d82e85996fecc53fe3e97c2a7b98',1,'join_network_door(infos_st *infos):&#160;atrier.c'],['../atrier_8c.html#a4bc5d82e85996fecc53fe3e97c2a7b98',1,'join_network_door(infos_st *infos):&#160;atrier.c']]]
];
