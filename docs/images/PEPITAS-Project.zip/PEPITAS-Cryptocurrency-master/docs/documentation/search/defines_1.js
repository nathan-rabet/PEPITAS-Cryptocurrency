var searchData=
[
  ['block_5fdata_5fsize_810',['BLOCK_DATA_SIZE',['../block_8h.html#a5eef11d8bacf39665e6c5a5eaf63c448',1,'block.h']]],
  ['block_5fsize_811',['BLOCK_SIZE',['../block_8h.html#ad51ded0bbd705f02f73fc60c0b721ced',1,'block.h']]],
  ['block_5ftest_5fc_812',['BLOCK_TEST_C',['../block__test_8c.html#a875133bab3aea3bf07978cf5adce0b8a',1,'block_test.c']]]
];
