var epoch__man_8h =
[
    [ "create_epoch_block", "epoch__man_8h.html#aeb0145b06d8c782e8536992cc1def819", null ],
    [ "create_vote_data", "epoch__man_8h.html#a99a18f9ea2a095bf023461087b211213", null ],
    [ "get_epoch_man_pkey", "epoch__man_8h.html#a600e69b60a52aa9e5976546b39ff2fab", null ],
    [ "give_punishments_and_rewards", "epoch__man_8h.html#aa998feeb3de235716cd0fa52951ead97", null ]
];