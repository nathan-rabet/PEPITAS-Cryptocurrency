var client_8h =
[
    [ "clear_epochs", "client_8h.html#a615d428cc2349cb563e4fa3d9212429a", null ],
    [ "clear_transactions", "client_8h.html#adcc4f847feef7ccada40e231100765f2", null ],
    [ "connection_to_others", "client_8h.html#ab7126685bb9b5dc07de54dbb8a8ba89d", null ],
    [ "get_infos", "client_8h.html#a480459f3451fa57a66df548ca0b408e3", null ],
    [ "join_network_door", "client_8h.html#a4bc5d82e85996fecc53fe3e97c2a7b98", null ],
    [ "move_file", "client_8h.html#a48484e0947e98ccf25a3eeddb669a9ca", null ],
    [ "new_transaction", "client_8h.html#a597346567fc95cf305a94063df3e86c3", null ],
    [ "update_blockchain", "client_8h.html#a2aa6779c93462c07f8a674546b72bd8b", null ],
    [ "update_blockchain_height", "client_8h.html#a6a6632fc31369b450613587243a58807", null ],
    [ "update_pdt", "client_8h.html#a35c808540bae041c9d4f83012c639426", null ],
    [ "update_pending_transactions_list", "client_8h.html#a22202ffd77ff472dddbec2ac501025f4", null ],
    [ "Validate", "client_8h.html#a6a17e4539f5b0c67dbd36bae0c2c0c8a", null ]
];