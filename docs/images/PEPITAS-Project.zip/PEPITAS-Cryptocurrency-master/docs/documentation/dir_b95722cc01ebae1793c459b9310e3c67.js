var dir_b95722cc01ebae1793c459b9310e3c67 =
[
    [ "client.c", "core_2network_2client_8c.html", "core_2network_2client_8c" ],
    [ "get_data.c", "get__data_8c.html", "get__data_8c" ],
    [ "network.c", "network_8c.html", "network_8c" ],
    [ "send_data.c", "send__data_8c.html", "send__data_8c" ],
    [ "server.c", "server_8c.html", "server_8c" ]
];