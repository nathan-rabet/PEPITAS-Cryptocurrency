var dir_7f57b1e41c5acd0e859ae5f3a2b075a9 =
[
    [ "blockchain", "dir_970168e4fc598f7815ebfaae486ffad9.html", "dir_970168e4fc598f7815ebfaae486ffad9" ],
    [ "cryptosystem", "dir_f4c924d95c8a1002b14665e0a9da530d.html", "dir_f4c924d95c8a1002b14665e0a9da530d" ],
    [ "misc", "dir_cd2dfb8956d87c3e23bff5bc3c96e5c3.html", "dir_cd2dfb8956d87c3e23bff5bc3c96e5c3" ],
    [ "network", "dir_83fbd955906e9032510966d415c56495.html", "dir_83fbd955906e9032510966d415c56495" ],
    [ "ui", "dir_fb6db9e3c1971fd2df53ff72f9853e3f.html", "dir_fb6db9e3c1971fd2df53ff72f9853e3f" ],
    [ "validation", "dir_1abae5ba6b7c6bf935bd52333e3d90cb.html", "dir_1abae5ba6b7c6bf935bd52333e3d90cb" ],
    [ "client.h", "client_8h.html", "client_8h" ]
];