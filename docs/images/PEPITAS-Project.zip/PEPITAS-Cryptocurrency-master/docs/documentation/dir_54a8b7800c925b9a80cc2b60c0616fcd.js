var dir_54a8b7800c925b9a80cc2b60c0616fcd =
[
    [ "block.c", "block_8c.html", "block_8c" ],
    [ "blockchain_header.c", "blockchain__header_8c.html", "blockchain__header_8c" ],
    [ "transaction.c", "transaction_8c.html", "transaction_8c" ],
    [ "wallet.c", "wallet_8c.html", "wallet_8c" ]
];