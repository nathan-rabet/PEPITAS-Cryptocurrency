var epoch__man_8c =
[
    [ "add_pdt_to_block", "epoch__man_8c.html#a20031a15e7ca013e4b21f6c4e5aff508", null ],
    [ "create_epoch_block", "epoch__man_8c.html#aeb0145b06d8c782e8536992cc1def819", null ],
    [ "create_vote_data", "epoch__man_8c.html#a99a18f9ea2a095bf023461087b211213", null ],
    [ "get_epoch_man_pkey", "epoch__man_8c.html#a600e69b60a52aa9e5976546b39ff2fab", null ],
    [ "give_punishments_and_rewards", "epoch__man_8c.html#ac6bdf21a7a1ab2b06e3b5b8b8c6c5a37", null ]
];