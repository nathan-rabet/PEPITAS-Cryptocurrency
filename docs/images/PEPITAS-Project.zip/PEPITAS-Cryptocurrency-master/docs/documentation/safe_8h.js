var safe_8h =
[
    [ "safe_fread", "safe_8h.html#ac4bf776335d7193068afa656b91a8827", null ],
    [ "safe_read", "safe_8h.html#a5cdb8f1fd0a2b177164e88074639a648", null ],
    [ "safe_send", "safe_8h.html#aeb28bdb1609a5e208b7840b471413e81", null ],
    [ "safe_write", "safe_8h.html#a405edff38f586c79822927a3b981e504", null ]
];