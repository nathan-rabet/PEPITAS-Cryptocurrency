var files_dup =
[
    [ "headers", "dir_7f57b1e41c5acd0e859ae5f3a2b075a9.html", "dir_7f57b1e41c5acd0e859ae5f3a2b075a9" ],
    [ "src", "dir_68267d1309a1af8e8297ef4c3efbcdba.html", "dir_68267d1309a1af8e8297ef4c3efbcdba" ],
    [ "tests", "dir_59425e443f801f1f2fd8bbe4959a3ccf.html", "dir_59425e443f801f1f2fd8bbe4959a3ccf" ]
];