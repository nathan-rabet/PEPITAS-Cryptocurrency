
#include "network/server.h"

int main()
{
    printf("Testing init_server()\n");
    return init_server();
}