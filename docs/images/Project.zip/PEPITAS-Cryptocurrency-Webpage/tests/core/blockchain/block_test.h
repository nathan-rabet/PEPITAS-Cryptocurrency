void genererate_random_blocks_test(void);

void block_test(void);